from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class Event(BaseModel):
    event_id: Optional[int]
    title: str
    description: Optional[str]
    location: str
    date: datetime
    capacity: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
